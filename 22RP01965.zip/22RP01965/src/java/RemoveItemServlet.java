import java.io.IOException;
import java.net.URLEncoder;
import java.net.URLDecoder;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RemoveItemServlet")
public class RemoveItemServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String item = request.getParameter("item");
        item = URLEncoder.encode(item, "UTF-8");
        
        // Get the current cart from cookies
        Cookie[] cookies = request.getCookies();
        String cart = "";
        
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("cart")) {
                    cart = URLDecoder.decode(cookie.getValue(), "UTF-8");
                    break;
                }
            }
        }

        // Remove the item from the cart
        if (!cart.isEmpty()) {
            String[] items = cart.split(",");
            ArrayList<String> itemList = new ArrayList<>();
            for (String i : items) {
                if (!i.equals(item)) {
                    itemList.add(i);
                }
            }
            cart = String.join(",", itemList);
        }
        
        // Update the cart cookie
        Cookie cartCookie = new Cookie("cart", URLEncoder.encode(cart, "UTF-8"));
        cartCookie.setMaxAge(60*60*24); // Set cookie to expire in 1 day
        response.addCookie(cartCookie);
        
        response.sendRedirect("ViewCartServlet");
    }
}
